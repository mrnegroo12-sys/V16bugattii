package com.sketchbot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle
import android.graphics.Bitmap
import android.view.Display
import android.os.Build
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class DrawService : AccessibilityService() {

    companion object { var instance: DrawService? = null }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var wm: WindowManager? = null
    private var panel: View? = null
    private var panelX = -1
    private var panelY = -1
    private var calib: View? = null
    private var card: View? = null
    private var banner: View? = null
    private var rect: RectF? = null
    private var layerP0: PointF? = null
    private var layerP1: PointF? = null
    // [أيقونة اللون، حقل HEX، زر تأكيد (اختياري)، إغلاق المحرر]
    private var colorPts: List<PointF?>? = null
    private var fillSel: List<PointF?>? = null
    private var brushSel: List<PointF?>? = null
    private var smudgeSel: List<PointF?>? = null
    // تعليم حقل Size: [أيقونة فتح لوحة الفرشاة، حقل Size، زر الإغلاق (اختياري)]
    private var sizeSel: List<PointF?>? = null
    private var dualOn = false
    private var mapOx = 0f
    private var mapOy = 0f
    private var mapSc = 1f
    private var curSize = -1
    private var smallSize = 10
    private var bigSize = 20
    private var curColor = -1
    private var stepNo = 0

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadPrefs()
        showPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun removeOverlay(v: View?) {
        if (v == null) return
        try { wm?.removeView(v) } catch (_: Exception) {}
    }

    private fun cleanup() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay(panel)
        removeOverlay(calib)
        removeOverlay(card)
        removeOverlay(banner)
        panel = null
        calib = null
        card = null
        banner = null
        instance = null
    }

    private fun toast(s: String) = Toast.makeText(this, Tr.t(s), Toast.LENGTH_SHORT).show()

    private fun overlayParams(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
    )

    // ---------- الحفظ ----------
    private fun prefs() = getSharedPreferences("sb", Context.MODE_PRIVATE)

    private fun loadPrefs() {
        val p = prefs()
        if (p.contains("l")) {
            rect = RectF(p.getFloat("l", 0f), p.getFloat("t", 0f), p.getFloat("r", 0f), p.getFloat("b", 0f))
        }
        if (p.contains("lx0")) {
            layerP0 = PointF(p.getFloat("lx0", 0f), p.getFloat("ly0", 0f))
            layerP1 = PointF(p.getFloat("lx1", 0f), p.getFloat("ly1", 0f))
        }
        fillSel = decodePts(p.getString("fillSel", null))
        brushSel = decodePts(p.getString("brushSel", null))
        smudgeSel = decodePts(p.getString("smudgeSel", null))
        sizeSel = decodePts(p.getString("sizeSel", null))
        colorPts = decodePts(p.getString("colorSel", null))?.takeIf { it.size == 4 }
    }

    private fun encodePts(l: List<PointF?>) =
        l.joinToString(";") { if (it == null) "n" else "${it.x},${it.y}" }

    private fun decodePts(s: String?): List<PointF?>? {
        if (s.isNullOrEmpty()) return null
        return try {
            s.split(";").map {
                if (it == "n") null else { val a = it.split(","); PointF(a[0].toFloat(), a[1].toFloat()) }
            }
        } catch (_: Exception) { null }
    }

    private fun saveRect(r: RectF) {
        prefs().edit()
            .putFloat("l", r.left).putFloat("t", r.top).putFloat("r", r.right).putFloat("b", r.bottom).apply()
    }

    private fun saveLayers(a: PointF, b: PointF) {
        prefs().edit()
            .putFloat("lx0", a.x).putFloat("ly0", a.y).putFloat("lx1", b.x).putFloat("ly1", b.y).apply()
    }

    private fun saveColorPts(l: List<PointF?>) {
        prefs().edit().putString("colorSel", encodePts(l)).apply()
    }

    private fun clearColorPts() {
        prefs().edit().remove("colorSel").apply()
        colorPts = null
    }

    // ---------- الشريط العائم ----------
    private fun showPanel() {
        val w = wm ?: return
        Th.init(this)
        val d = resources.displayMetrics.density
        fun col(a: String, b: String) = Pair(Color.parseColor(a), Color.parseColor(b))
        fun wb(icon: Int, cap: String, c: Pair<Int, Int>, glyph: Int = 0) = WaterButton(this, icon, cap, c.first, c.second, glyph)
        val handle = IconView(this, Ic.MENU, 0, 0, Color.parseColor("#D2540C")).apply { setPadding((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt()) }
        val brand = WarmGradientText(this).apply {
            text = "MR NEGROO"
            textSize = 15f
            typeface = Ui.black()
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
        }
        val bStart = wb(Ic.PLAY, "ابدأ", col("#FFA23A", "#E8500B"))
        val bStop = wb(Ic.STOP, "إيقاف", col("#F58A7A", "#D9392E"))
        val bCal = wb(Ic.AREA, "المنطقة", col("#FFAA3C", "#EA620F"))
        val bLay = wb(Ic.LAYERS, "طبقات", col("#A47552", "#6B4228"))
        val bColor = wb(Ic.PALETTE, "اللون", col("#FF8654", "#E03A1E"))
        val bFill = wb(Ic.BUCKET, "Fill", col("#FFBE55", "#E8820C"))
        val bBrush = wb(Ic.BRUSH, "الفرشاة", col("#BE848C", "#7A4A52"))
        val bTest = wb(Ic.TEST, "اختبار", col("#FFC45E", "#EE8A12"))
        val bSize = wb(Ic.RULER, "الحجم", col("#FFB45E", "#E8760F"))
        val bMeasure = wb(Ic.RULER, "قياس الفرشاة", if (Th.dark) Pair(Color.parseColor("#5A3D2C"), Color.parseColor("#3A2519")) else Pair(Color.argb(0xC0, 255, 250, 242), Color.argb(0x70, 232, 212, 190)), Th.BROWN)
        fun cell(v: View) = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
        }
        fun rowOf(vararg v: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
            for (x in v) addView(x, cell(x))
        }
        var ps = prefs().getFloat("panelScale", 1f).coerceIn(0.5f, 1.6f)
        val row0 = FrameLayout(this).apply {
            addView(handle, FrameLayout.LayoutParams((30 * d).toInt(), (30 * d).toInt(), Gravity.START or Gravity.CENTER_VERTICAL))
            addView(brand, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            background = WarmDrawable(WarmDrawable.PANEL, 30f, d)
            setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (20 * d).toInt())
            addView(row0, LinearLayout.LayoutParams(-1, (44 * d).toInt()))
            addView(rowOf(bStart, bStop))
            addView(rowOf(bCal, bLay))
            addView(rowOf(bColor, bFill))
            addView(rowOf(bBrush, bTest))
            addView(rowOf(bMeasure, bSize))
        }
        root.measure(
            View.MeasureSpec.makeMeasureSpec((310 * d).toInt(), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val natH = root.measuredHeight
        root.pivotX = 0f
        root.pivotY = 0f
        root.scaleX = ps
        root.scaleY = ps
        val box = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            addView(root, FrameLayout.LayoutParams((310 * d).toInt(), natH))
        }
        val grip = GripView(this)
        val gs = (26 * d).toInt()
        box.addView(grip, FrameLayout.LayoutParams(gs, gs, Gravity.TOP or Gravity.START))
        fun placeGrip() {
            grip.translationX = 310 * d * ps - gs
            grip.translationY = natH * ps - gs
        }
        placeGrip()
        val lp = overlayParams(
            (310 * d * ps).toInt(),
            (natH * ps).toInt(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (panelX < 0) (8 * d).toInt() else panelX
            y = if (panelY < 0) (240 * d).toInt() else panelY
        }

        // السحب من أي مكان فارغ في اللوحة (العنوان، الفراغات، الحواف)
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    // حرّة خارج حدود الشاشة، مع إبقاء 44dp ظاهرة حتى لا تضيع اللوحة نهائياً
                    val dm = resources.displayMetrics
                    val keep = (44 * d).toInt()
                    lp.x = (sx + (e.rawX - dx).toInt()).coerceIn(keep - lp.width, dm.widthPixels - keep)
                    lp.y = (sy + (e.rawY - dy).toInt()).coerceIn(keep - lp.height, dm.heightPixels - keep)
                    panelX = lp.x; panelY = lp.y
                    try { w.updateViewLayout(box, lp) } catch (_: Exception) {}
                }
            }
            true
        }
        // قصّ الحجم بالسحب من الزاوية السفلية اليمنى (50% – 160%)
        var gx = 0f; var gy = 0f; var gw = 0f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    gx = e.rawX; gy = e.rawY; gw = 310 * d * ps; Haptic.tap(this)
                    // النافذة بأقصى حجم أثناء السحب: التكبير/التصغير يتم بخصائص العرض فقط (سلس بلا إعادة تخطيط)
                    lp.width = (310 * d * 1.6f).toInt()
                    lp.height = (natH * 1.6f).toInt()
                    try { w.updateViewLayout(box, lp) } catch (_: Exception) {}
                }
                MotionEvent.ACTION_MOVE -> {
                    val nw = gw + ((e.rawX - gx) + (e.rawY - gy)) / 2f
                    ps = (nw / (310 * d)).coerceIn(0.5f, 1.6f)
                    root.scaleX = ps
                    root.scaleY = ps
                    placeGrip()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    prefs().edit().putFloat("panelScale", ps).apply()
                    lp.width = (310 * d * ps).toInt()
                    lp.height = (natH * ps).toInt()
                    try { w.updateViewLayout(box, lp) } catch (_: Exception) {}
                }
            }
            true
        }
        bStart.setOnClickListener { startDrawing() }
        bStop.setOnClickListener { stop(); toast("تم الإيقاف") }
        bCal.setOnClickListener { calibrate() }
        bLay.setOnClickListener { teachLayers() }
        bColor.setOnClickListener { teachColor() }
        bColor.setOnLongClickListener {
            clearColorPts()
            toast("تم مسح تعليم اللون: سيعود الاختيار اليدوي")
            true
        }

        bTest.setOnClickListener { testColor() }
        bFill.setOnClickListener { teachTool(1) }
        bBrush.setOnClickListener { teachTool(0) }
        bMeasure.setOnClickListener { measureBrush() }
        bSize.setOnClickListener { teachSize() }
        bSize.setOnLongClickListener {
            sizeSel = null
            prefs().edit().remove("sizeSel").remove("bigScreen").apply()
            toast("تم مسح تعليم Size: سيُرسم بفرشاة واحدة")
            true
        }
        bFill.setOnLongClickListener {
            fillSel = null; prefs().edit().remove("fillSel").apply()
            toast("تم مسح تعليم أداة Fill: سيطلب منك اختيارها يدوياً")
            true
        }
        bBrush.setOnLongClickListener {
            brushSel = null; prefs().edit().remove("brushSel").apply()
            toast("تم مسح تعليم الفرشاة: سيطلب منك اختيارها يدوياً")
            true
        }

        w.addView(box, lp)
        panel = box
    }

    // ---------- بطاقة اختيار اللون (الوضع اليدوي) ----------
    private fun showColorCard(ph: Phase, idx: Int, total: Int, onContinue: () -> Unit) {
        val w = wm ?: return
        removeOverlay(card)
        val dn = resources.displayMetrics.density
        val hex = String.format("#%06X", 0xFFFFFF and ph.color)
        setClipboard(hex)
        val swatch = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = 12 * dn
                setColor(ph.color)
                setStroke((2 * dn).toInt(), Color.WHITE)
            }
            elevation = 3 * dn
        }
        val pill = warmPill("متابعة", true)
        val root = warmCard("المرحلة $idx/$total: ${ph.label}\n$hex\nاختر اللون ثم متابعة", swatch, pill)
        val lp = overlayParams(
            (340 * dn).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (40 * dn).toInt()
        }
        pill.setOnClickListener {
            handler.postDelayed({
                removeOverlay(root)
                card = null
                onContinue()
            }, 220)
        }
        w.addView(root, lp)
        card = root
    }

    // ---------- شاشات التعليم ----------
    private class CalibView(ctx: Context) : View(ctx) {
        var a: PointF? = null
        var b: PointF? = null
        private val p = Paint().apply {
            color = 0xFFFF4081.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(0x33000000)
            val pa = a
            val pb = b
            if (pa != null) c.drawCircle(pa.x, pa.y, 20f, p)
            if (pb != null) c.drawCircle(pb.x, pb.y, 20f, p)
            if (pa != null && pb != null) c.drawRect(
                Math.min(pa.x, pb.x), Math.min(pa.y, pb.y),
                Math.max(pa.x, pb.x), Math.max(pa.y, pb.y), p
            )
        }
    }

    private class TapView(ctx: Context) : View(ctx) {
        val pts = ArrayList<PointF>()
        private val p = Paint().apply {
            color = 0xFF40C4FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(0x22000000)
            for (pt in pts) c.drawCircle(pt.x, pt.y, 24f, p)
        }
    }

    private fun fullScreenParams() = overlayParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    )

    // زاويتا الصورة المرجعية داخل Sketchbook
    private fun calibrate() {
        val w = wm ?: return
        if (calib != null) return
        val v = CalibView(this)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                if (v.a == null) {
                    v.a = PointF(e.rawX, e.rawY)
                    v.invalidate()
                    toast("الآن اضغط الزاوية السفلية اليمنى لمنطقة الرسم")
                } else if (v.b == null) {
                    val a = v.a!!
                    v.b = PointF(e.rawX, e.rawY)
                    val r = RectF(
                        Math.min(a.x, e.rawX), Math.min(a.y, e.rawY),
                        Math.max(a.x, e.rawX), Math.max(a.y, e.rawY)
                    )
                    v.invalidate()
                    if (r.width() < 150f || r.height() < 150f) {
                        toast("المساحة صغيرة جداً، أعد المحاولة")
                    } else {
                        rect = r
                        saveRect(r)
                        toast("تم حفظ منطقة الرسم")
                    }
                    handler.postDelayed({
                        removeOverlay(v)
                        calib = null
                    }, 1200)
                }
            }
            true
        }
        w.addView(v, fullScreenParams())
        calib = v
        toast("اضغط الزاوية العليا اليسرى لمنطقة الرسم")
    }

    // ---------- التعليم خطوة بخطوة ----------
    private class Step(val text: String, val wait: Boolean)

    // ---------- إشعار الاكتمال: لافتة + اهتزاز + صوت + إشعار نظام ----------
    private fun notifyDone() {
        toast("اكتمل الرسم ✓")
        try {
            val w = wm
            if (w != null) {
                removeOverlay(banner)
                val d = resources.displayMetrics.density
                val tv = TextView(this)
                tv.text = "✓  " + Tr.t("اكتمل الرسم")
                tv.setTextColor(Color.WHITE)
                tv.textSize = 19f
                tv.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
                tv.gravity = Gravity.CENTER
                tv.background = WarmDrawable(WarmDrawable.ORANGE, 26f, d)
                tv.setPadding((18 * d).toInt(), (14 * d).toInt(), (18 * d).toInt(), (14 * d).toInt())
                val lp = overlayParams(
                    (320 * d).toInt(),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                )
                lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                lp.y = (70 * d).toInt()
                w.addView(tv, lp)
                banner = tv
                handler.postDelayed({ if (banner === tv) { removeOverlay(banner); banner = null } }, 6000)
            }
        } catch (_: Exception) {}
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager
                vm.defaultVibrator.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 200, 120, 200, 120, 450), -1))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 200, 120, 200, 120, 450), -1))
                else @Suppress("DEPRECATION") v.vibrate(longArrayOf(0, 200, 120, 200, 120, 450), -1)
            }
        } catch (_: Exception) {}
        try {
            val r = android.media.RingtoneManager.getRingtone(
                this, android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
            )
            r.play()
        } catch (_: Exception) {}
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel("done", "اكتمال الرسم", android.app.NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val b = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, "done") else android.app.Notification.Builder(this)
            val n = b.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MR NEGROO")
                .setContentText(Tr.t("اكتمل الرسم") + " ✓")
                .setAutoCancel(true)
                .build()
            nm.notify(7, n)
        } catch (_: Exception) {}
    }

    // ---------- بطاقات التعليم بالتصميم الدافئ (مدمجة وتفاعلية) ----------
    private fun iconFor(text: String): Triple<Int, Int, Int> = when {
        text.contains("Size") || text.contains("الحجم") -> Triple(Ic.RULER, Color.parseColor("#FFB45E"), Color.parseColor("#E8760F"))
        text.contains("طبقات") || text.contains("الطبقة") -> Triple(Ic.LAYERS, Color.parseColor("#A47552"), Color.parseColor("#6B4228"))
        text.contains("Fill") -> Triple(Ic.BUCKET, Color.parseColor("#FFBE55"), Color.parseColor("#E8820C"))
        text.contains("HEX") || text.contains("لون") || text.contains("اللون") -> Triple(Ic.PALETTE, Color.parseColor("#FF8654"), Color.parseColor("#E03A1E"))
        text.contains("فرش") -> Triple(Ic.BRUSH, Color.parseColor("#BE848C"), Color.parseColor("#7A4A52"))
        else -> Triple(Ic.AREA, Color.parseColor("#FFAA3C"), Color.parseColor("#EA620F"))
    }

    private fun tileFor(text: String): View {
        val t = iconFor(text)
        return IconView(this, t.first, t.second, t.third, 0, true)
    }

    private fun warmPill(label: String, orange: Boolean): DropLinear {
        val d = resources.displayMetrics.density
        return DropLinear(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = WarmDrawable(if (orange) WarmDrawable.ORANGE else WarmDrawable.BTN, 20f, d)
            setPadding((14 * d).toInt(), (9 * d).toInt(), (14 * d).toInt(), (9 * d).toInt())
            dropColor = if (orange) Color.parseColor("#FF8A1F") else Color.parseColor("#E5470B")
            if (orange) addView(IconView(this@DrawService, Ic.PLAY, 0, 0, Color.WHITE), LinearLayout.LayoutParams((14 * d).toInt(), (14 * d).toInt()))
            addView(Th.text(this@DrawService, label, 13.5f, if (orange) Color.WHITE else Th.BROWN, true).apply {
                maxLines = 1
                setPadding((if (orange) 6 else 0) * d.toInt(), 0, 0, 0)
            })
        }
    }

    private fun warmCard(text: String, tile: View, pill: DropLinear?): LinearLayout {
        val d = resources.displayMetrics.density
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
            background = WarmDrawable(WarmDrawable.PANEL, 24f, d)
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            addView(tile, LinearLayout.LayoutParams((38 * d).toInt(), (38 * d).toInt()))
            addView(Th.text(this@DrawService, text, 12.5f, Th.BROWN, true).apply {
                maxLines = 3
                setPadding((10 * d).toInt(), 0, (8 * d).toInt(), 0)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            if (pill != null) addView(pill)
        }
    }

    private fun showBanner(text: String) {
        val w = wm ?: return
        removeOverlay(banner)
        val d = resources.displayMetrics.density
        val tv = warmCard(text, tileFor(text), null)
        val lp = overlayParams(
            (330 * d).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (48 * d).toInt()
        w.addView(tv, lp)
        banner = tv
    }

    // خطوة ضغط: تضغط أنت المكان فيحفظه التطبيق (لا يصل الضغط إلى Sketchbook)
    private fun tapStep(text: String, onSkip: (() -> Unit)? = null, onTap: (PointF) -> Unit) {
        val w = wm ?: return
        val v = TapView(this)
        var done = false
        showBanner(text)
        var skipView: View? = null
        fun cleanupStep() {
            removeOverlay(v)
            calib = null
            removeOverlay(banner)
            banner = null
            removeOverlay(skipView)
            skipView = null
        }
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP && !done) {
                done = true
                val p = PointF(e.rawX, e.rawY)
                v.pts.add(p)
                v.invalidate()
                handler.postDelayed({
                    cleanupStep()
                    onTap(p)
                }, 350)
            }
            true
        }
        w.addView(v, fullScreenParams())
        calib = v
        if (onSkip != null) {
            val d = resources.displayMetrics.density
            val sk = warmPill("تخطي (غير مطلوب)", false)
            val lp = overlayParams(
                (WindowManager.LayoutParams.WRAP_CONTENT), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            )
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.y = (40 * d).toInt()
            sk.setOnClickListener {
                if (!done) {
                    done = true
                    cleanupStep()
                    onSkip()
                }
            }
            w.addView(sk, lp)
            skipView = sk
        }
    }

    // خطوة انتظار: تفعل أنت شيئاً في Sketchbook ثم تضغط متابعة
    private fun waitStep(text: String, onContinue: () -> Unit) {
        val w = wm ?: return
        removeOverlay(card)
        val d = resources.displayMetrics.density
        val pill = warmPill("متابعة", true)
        val root = warmCard(text, tileFor(text), pill)
        val lp = overlayParams(
            (340 * d).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.y = (24 * d).toInt()
        pill.setOnClickListener {
            handler.postDelayed({
                removeOverlay(root)
                card = null
                onContinue()
            }, 220)
        }
        w.addView(root, lp)
        card = root
    }

    private fun teachSteps(steps: List<Step>, onDone: (List<PointF>) -> Unit) {
        if (calib != null) return
        val pts = ArrayList<PointF>()
        fun next(i: Int) {
            if (i >= steps.size) { onDone(pts); return }
            val st = steps[i]
            if (st.wait) waitStep(st.text) { next(i + 1) }
            else tapStep(st.text) { p -> pts.add(p); next(i + 1) }
        }
        next(0)
    }

    private fun teachLayers() {
        teachSteps(
            listOf(
                Step("افتح لوحة الطبقات في Sketchbook بنفسك، ثم اضغط متابعة", true),
                Step("اضغط أيقونة الطبقات", false),
                Step("اضغط زر ⊕ إضافة طبقة جديدة", false)
            )
        ) { l ->
            layerP0 = l[0]
            layerP1 = l[1]
            saveLayers(l[0], l[1])
            toast("تم حفظ الطبقات. أغلق لوحة الطبقات الآن")
        }
    }

    // تعليم اختيار أداة (Fill أو الفرشاة): أيقونة اللوحة ← الأداة ← زر الإغلاق (اختياري)
    private fun teachTool(kind: Int) {
        if (calib != null) return
        val name = when (kind) {
            1 -> "أداة التعبئة (Fill / سطل الطلاء)"
            2 -> "أداة التنعيم (Smudge)"
            else -> "الفرشاة أو القلم الرفيع"
        }
        val key = when (kind) { 1 -> "fillSel"; 2 -> "smudgeSel"; else -> "brushSel" }
        val pts = arrayOfNulls<PointF>(3)
        fun finish() {
            val l = pts.toList()
            when (kind) { 1 -> fillSel = l; 2 -> smudgeSel = l; else -> brushSel = l }
            prefs().edit().putString(key, encodePts(l)).apply()
            toast("تم حفظ $name. تأكد أن اللوحة مغلقة الآن")
        }
        tapStep("اضغط أيقونة الفرش في الشريط العلوي (التي تفتح لوحة الأدوات)") { a ->
            pts[0] = a
            waitStep("افتح لوحة الفرش بنفسك الآن ثم اضغط متابعة") {
                tapStep("اضغط على $name داخل اللوحة") { b ->
                    pts[1] = b
                    waitStep("اختر $name بنفسك الآن (اضغط عليها فعلاً) ثم اضغط متابعة") {
                        tapStep(
                            "اضغط الزر الذي يُغلق اللوحة (مثلاً أيقونة الفرش مجدداً)، وإن كانت تُغلق تلقائياً فاضغط تخطي",
                            onSkip = { finish() }
                        ) { c ->
                            pts[2] = c
                            finish()
                        }
                    }
                }
            }
        }
    }

    // تعليم اللون: ثلاث ضغطات فقط (الكتابة ومسح القيمة القديمة يتولاهما البوت وحده)
    private fun teachColor() {
        if (calib != null) return
        val pts = arrayOfNulls<PointF>(4)
        tapStep("المحرر مغلق الآن. اضغط أيقونة اللون في الشريط العلوي (عجلة الألوان)") { a ->
            pts[0] = a
            waitStep("افتح محرر اللون بنفسك، ثم اضغط متابعة") {
                tapStep("اضغط على حقل HEX (المكان الذي يُكتب فيه رمز اللون)") { b ->
                    pts[1] = b
                    tapStep("اضغط ✕ الذي يغلق محرر اللون") { d ->
                        pts[3] = d
                        val l = pts.toList()
                        colorPts = l
                        saveColorPts(l)
                        toast("تم حفظ اللون. أغلق محرر اللون الآن")
                    }
                }
            }
        }
    }

    // ---------- اللمسات ----------
    private fun tapAt(x: Float, y: Float, duration: Long, onDone: () -> Unit) = tapAtD(x, y, duration, 700L, onDone)

    private fun tapAtD(x: Float, y: Float, duration: Long, delay: Long, onDone: () -> Unit) {
        val path = Path()
        path.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                handler.postDelayed({ if (running) onDone() }, delay)
            }
            override fun onCancelled(d: GestureDescription?) { running = false }
        }, null)
        if (!ok) running = false
    }

    private fun setClipboard(text: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("color", text))
        } catch (_: Exception) {}
    }

    // يضع رمز اللون في الحافظة ثم: فتح المحرر ← الضغط على HEX ← لصق ← إغلاق
    // ---------- قياس سمك الفرشاة الفعلي على الشاشة ----------
    private fun measureBrush() {
        val r = rect
        if (r == null) { toast("حدّد منطقة الرسم (⛶) أولاً"); return }
        if (Build.VERSION.SDK_INT < 30) { toast("القياس التلقائي يتطلب Android 11 فما فوق"); return }
        if (running) return
        running = true
        val cx = r.centerX()
        val cy = r.centerY()
        toast("سيرسم خطاً تجريبياً في وسط منطقة الرسم")
        val path = Path()
        path.moveTo(cx - 90f, cy)
        path.lineTo(cx + 90f, cy)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 500))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                handler.postDelayed({
                    takeShotAndMeasure(cx, cy) { t ->
                        running = false
                        if (t >= 1f) {
                            prefs().edit().putFloat("brushScreen", t).apply()
                            toast("سمك الفرشاة المقاس = ${t.toInt()} بكسل. تراجع ↩ عن الخط التجريبي، ثم أعد فتح صفحة التطبيق")
                        } else toast("لم أجد الخط التجريبي: تأكد أن وسط منطقة الرسم فارغ وأن لون الفرشاة يختلف عن لون الكانفس")
                    }
                }, 900)
            }
            override fun onCancelled(d: GestureDescription?) { running = false }
        }, null)
        if (!ok) running = false
    }

    // ---------- Size: التعليم + الكتابة + المعايرة ----------
    private fun teachSize() {
        if (calib != null) return
        val pts = arrayOfNulls<PointF>(3)
        fun finish() {
            val l = pts.toList()
            sizeSel = l
            prefs().edit().putString("sizeSel", encodePts(l)).apply()
            toast("تم حفظ حقل Size. جاري معايرة الفرشاتين...")
            handler.postDelayed({ calibrateSize() }, 900)
        }
        tapStep("اضغط أيقونة الفرش لفتح لوحة الفرشاة (التي فيها حقل Size)") { a ->
            pts[0] = a
            waitStep("افتح لوحة الفرشاة بنفسك حتى يظهر حقل Size ثم اضغط متابعة") {
                tapStep("اضغط على حقل Size (الرقم الذي يُكتب فيه الحجم)") { b ->
                    pts[1] = b
                    tapStep("اضغط الزر الذي يُغلق اللوحة، وإن كانت تُغلق تلقائياً فاضغط تخطي", onSkip = { finish() }) { c ->
                        pts[2] = c
                        finish()
                    }
                }
            }
        }
    }

    // يكتب رقماً في الحقل المركّز حالياً (نفس طريقة كتابة HEX)
    private fun typeNumber(txt: String): Boolean {
        try {
            val root = rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val old = node.text?.toString() ?: ""
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, old.length)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, txt)
            val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (ok && Build.VERSION.SDK_INT >= 30) node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            return ok
        } catch (_: Exception) { return false }
    }

    // يغيّر قيمة Size في Sketchbook: فتح اللوحة ← الضغط على الحقل ← كتابة الرقم ← إغلاق
    private fun setBrushSize(n: Int, onDone: () -> Unit) {
        val p = sizeSel
        if (p == null || p[0] == null || p[1] == null) { onDone(); return }
        tapAtD(p[0]!!.x, p[0]!!.y, 80, 700L) {
            tapAtD(p[1]!!.x, p[1]!!.y, 80, 900L) {
                if (!typeNumber(n.toString())) toast("تعذّرت كتابة Size تلقائياً: اكتب $n بنفسك")
                handler.postDelayed({
                    val c = p[2]
                    if (c != null) tapAtD(c.x, c.y, 80, 700L) { handler.postDelayed({ onDone() }, 500) }
                    else handler.postDelayed({ onDone() }, 500)
                }, 700)
            }
        }
    }

    private fun ensureSize(n: Int, onDone: () -> Unit) {
        if (!running) return
        if (!dualOn || curSize == n) { onDone(); return }
        setBrushSize(n) { curSize = n; onDone() }
    }

    // يرسم خطاً تجريبياً ويقيس سمكه ثم يعيد النتيجة
    private fun testLine(cx: Float, cy: Float, cb: (Float) -> Unit) {
        val path = Path()
        path.moveTo(cx - 90f, cy)
        path.lineTo(cx + 90f, cy)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 500)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                handler.postDelayed({ takeShotAndMeasure(cx, cy, cb) }, 900)
            }
            override fun onCancelled(d: GestureDescription?) { cb(0f) }
        }, null)
        if (!ok) cb(0f)
    }

    // معايرة: يضبط Size الصغير ثم الكبير ويقيس سمك كل منهما على الشاشة
    private fun calibrateSize() {
        val r = rect
        if (sizeSel == null) { toast("علّم حقل Size أولاً (زر الحجم)"); return }
        if (r == null) { toast("حدّد منطقة الرسم (⛶) أولاً ثم اضغط مطولاً على قياس الفرشاة"); return }
        if (Build.VERSION.SDK_INT < 30) { toast("المعايرة التلقائية تتطلب Android 11 فما فوق"); return }
        if (running) return
        running = true
        dualOn = true
        curSize = -1
        val cx = r.centerX()
        val cy = r.centerY()
        toast("معايرة: سيرسم خطين تجريبيين بحجمين مختلفين")
        setBrushSize(smallSize) {
            curSize = smallSize
            testLine(cx, cy - r.height() * 0.15f) { t1 ->
                if (t1 < 1f) { running = false; dualOn = false; toast("لم أجد الخط التجريبي: تأكد أن وسط منطقة الرسم فارغ وأن لون الفرشاة يختلف عن لون الكانفس"); return@testLine }
                setBrushSize(bigSize) {
                    curSize = bigSize
                    testLine(cx, cy + r.height() * 0.15f) { t2 ->
                        running = false
                        dualOn = false
                        if (t2 < 1f) { toast("لم أجد الخط التجريبي: تأكد أن وسط منطقة الرسم فارغ وأن لون الفرشاة يختلف عن لون الكانفس"); return@testLine }
                        prefs().edit().putFloat("brushScreen", t1).putFloat("bigScreen", t2).apply()
                        toast("الفرشاة الصغيرة = ${t1.toInt()} بكسل، الكبيرة = ${t2.toInt()} بكسل. تراجع ↩ مرتين عن الخطين، ثم أعد فتح صفحة التطبيق")
                    }
                }
            }
        }
    }

    private fun colorDist(a: Int, b: Int): Int =
        Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b)) + Math.abs(Color.blue(a) - Color.blue(b))

    @android.annotation.TargetApi(30)
    private fun takeShotAndMeasure(cx: Float, cy: Float, cb: (Float) -> Unit) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(res: ScreenshotResult) {
                    var t = 0f
                    try {
                        val hb = res.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, res.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        if (bmp != null) {
                            val x = cx.toInt().coerceIn(0, bmp.width - 1)
                            val y0 = cy.toInt().coerceIn(0, bmp.height - 1)
                            val bg = bmp.getPixel(x, (y0 - 90).coerceIn(0, bmp.height - 1))
                            val centerDist = colorDist(bmp.getPixel(x, y0), bg)
                            if (centerDist > 60) {
                                val th = centerDist / 2
                                var up = 0
                                var yy = y0 - 1
                                while (yy >= 0 && up < 200 && colorDist(bmp.getPixel(x, yy), bg) > th) { up++; yy-- }
                                var dn = 0
                                yy = y0 + 1
                                while (yy < bmp.height && dn < 200 && colorDist(bmp.getPixel(x, yy), bg) > th) { dn++; yy++ }
                                t = (up + dn + 1).toFloat()
                            }
                        }
                    } catch (_: Exception) {}
                    cb(t)
                }
                override fun onFailure(errorCode: Int) {
                    toast("تعذّر أخذ لقطة الشاشة (رمز $errorCode)")
                    cb(0f)
                }
            })
        } catch (e: Exception) {
            toast("تعذّر القياس: ${e.message}")
            cb(0f)
        }
    }

    // كتابة رمز HEX مباشرة في الحقل المحدد عبر خدمة إمكانية الوصول (دون لصق)
    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable || (n.className?.toString()?.contains("EditText") == true)) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun typeHex(hex: String): Boolean {
        try {
            val root = rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
            val old = node.text?.toString() ?: ""
            val txt = if (old.startsWith("#")) hex else hex.removePrefix("#")
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            // تحديد القيمة القديمة كاملة ثم استبدالها
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, old.length)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, txt)
            var ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (!ok) {
                node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
                })
                ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            }
            if (ok && Build.VERSION.SDK_INT >= 30) {
                node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            }
            return ok
        } catch (_: Exception) {
            return false
        }
    }

    private fun applyColor(color: Int, onDone: () -> Unit) {
        val p = colorPts
        if (p == null || p.size < 4 || p[0] == null || p[1] == null) { onDone(); return }
        val hex = String.format("#%06X", 0xFFFFFF and color)
        setClipboard(hex)
        val finishSteps = {
            val c = p[2]
            val x = p[3]
            val closeIt = { if (x != null) tapAtD(x.x, x.y, 80, 1000L) { onDone() } else onDone() }
            if (c != null) tapAtD(c.x, c.y, 80, 900L) { closeIt() } else closeIt()
        }
        handler.postDelayed({
            if (!running) return@postDelayed
            tapAtD(p[0]!!.x, p[0]!!.y, 80, 1300L) {
                tapAtD(p[1]!!.x, p[1]!!.y, 80, 1000L) {
                    if (typeHex(hex)) {
                        handler.postDelayed({ if (running) finishSteps() }, 700)
                    } else {
                        toast("تعذّر الكتابة تلقائياً: اكتب $hex بنفسك")
                        waitStep("اكتب $hex في حقل HEX بنفسك (الرمز في الحافظة) ثم اضغط متابعة") {
                            handler.postDelayed({ if (running) finishSteps() }, 500)
                        }
                    }
                }
            }
        }, 400)
    }

    // اختبار مستقل لتغيير اللون: يطبّق الأحمر مرة واحدة ثم تتحقق بنفسك
    private fun testColor() {
        if (colorPts == null) { toast("علّم اللون أولاً (🎨)"); return }
        if (running) return
        running = true
        toast("اختبار: سيُطبَّق الأحمر #FF0000")
        applyColor(0xFFFF0000.toInt()) {
            running = false
            toast("انتهى. ارسم خطاً بيدك: هل هو أحمر؟")
        }
    }

    private fun newLayer(onDone: () -> Unit) {
        val a = layerP0
        val b = layerP1
        if (a == null || b == null) { onDone(); return }
        tapAt(a.x, a.y, 60) {
            tapAt(b.x, b.y, 60) {
                tapAt(a.x, a.y, 60) { onDone() }
            }
        }
    }

    // ---------- الرسم ----------
    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay(card)
        card = null
        removeOverlay(banner)
        banner = null
    }

    private fun startDrawing() {
        val r = rect
        val src = Shared.phases
        if (src.isEmpty()) { toast("اختر صورة من التطبيق أولاً"); return }
        if (r == null) { toast("حدّد منطقة الرسم (⛶) أولاً"); return }
        if (running) return

        val iw = Shared.imgW.toFloat()
        val ih = Shared.imgH.toFloat()
        val sc = Math.min(r.width() / iw, r.height() / ih)
        val ox = r.left + (r.width() - iw * sc) / 2f
        val oy = r.top + (r.height() - ih * sc) / 2f
        mapOx = ox; mapOy = oy; mapSc = sc
        fun mx(px: Float) = ox + px * sc
        fun my(py: Float) = oy + py * sc

        val mapped = src.map { ph ->
            val ms = ph.strokes.map { st -> st.map { PointF(mx(it.x), my(it.y)) } }
            val mb = ph.big.map { st -> st.map { PointF(mx(it.x), my(it.y)) } }
            Phase(
                ph.color, ph.label, splitLong(order(ms)), ph.fast,
                if (ph.pickX >= 0f) mx(ph.pickX) else -1f,
                if (ph.pickY >= 0f) my(ph.pickY) else -1f,
                ph.fills?.map { PointF(mx(it.x), my(it.y)) },
                ph.blend,
                ph.fillAreas?.map { it * sc * sc },
                ph.fillFallback?.map { fb -> fb.map { st -> st.map { PointF(mx(it.x), my(it.y)) } } },
                splitLong(order(mb)),
                ph.cid
            )
        }
        running = true
        curColor = -1
        curSize = -1
        smallSize = smallSize.coerceAtLeast(1)
        dualOn = sizeSel != null && mapped.any { it.big.isNotEmpty() }
        stepNo = 0
        toast("جاري التحضير...")
        if (mapped.any { it.fills != null }) {
            handler.postDelayed({ runFillMode(mapped) }, 1200)
        } else {
            handler.postDelayed({ runPhase(mapped, 0) }, 1200)
        }
    }

    private fun runPhase(ps: List<Phase>, idx: Int) {
        if (!running) return
        if (idx >= ps.size) {
            if (dualOn && curSize != smallSize) { ensureSize(smallSize) { running = false; dualOn = false; notifyDone() }; return }
            running = false
            dualOn = false
            notifyDone()
            return
        }
        val ph = ps[idx]
        if (ph.blend) {
            if (Shared.layers) { toast("التنعيم يحتاج طبقة واحدة، تم تخطيه"); runPhase(ps, idx + 1); return }
            toast(ph.label)
            selectSel(smudgeSel, "اختر أداة التنعيم (Smudge) بنفسك ثم اضغط متابعة") {
                drawNext(ph.strokes, 0, true) {
                    selectTool(false) { runPhase(ps, idx + 1) }
                }
            }
            return
        }
        toast("${ph.label} (${idx + 1}/${ps.size})")
        val go = {
            if (running) {
                val next = { verifyPhase(ph, 0) { runPhase(ps, idx + 1) } }
                if (!dualOn) {
                    // بلا فرشاة مزدوجة: كل الضربات (بما فيها الكبيرة إن وُجدت) بالفرشاة الحالية
                    drawNext(ph.big + ph.strokes, 0, ph.fast, next)
                } else if (ph.big.isEmpty()) {
                    ensureSize(smallSize) { drawNext(ph.strokes, 0, ph.fast, next) }
                } else if (curSize == smallSize && ph.strokes.isNotEmpty()) {
                    // نبدأ بما يطابق الحجم الحالي لتقليل تبديلات Size
                    ensureSize(smallSize) {
                        drawNext(ph.strokes, 0, ph.fast) { ensureSize(bigSize) { drawNext(ph.big, 0, true, next) } }
                    }
                } else {
                    ensureSize(bigSize) {
                        drawNext(ph.big, 0, true) { ensureSize(smallSize) { drawNext(ph.strokes, 0, ph.fast, next) } }
                    }
                }
            }
        }
        if (ps.size == 1) {
            go()
            return
        }
        if (colorPts != null) {
            applyColor(ph.color) { if (Shared.layers) newLayer { go() } else go() }
        } else {
            showColorCard(ph, idx + 1, ps.size) { handler.postDelayed({ go() }, 700) }
        }
    }

    // ---------- التحقق من التغطية: لقطة شاشة ← كشف البكسلات التي لم تُلوَّن ← ترقيعها (حتى 4 جولات) ----------
    private fun verifyPhase(ph: Phase, pass: Int, onDone: () -> Unit) {
        if (!running) return
        if (Shared.lbl == null || ph.cid < 0 || pass >= 4 || Build.VERSION.SDK_INT < 30) { onDone(); return }
        handler.postDelayed({ if (running) shotAndPatch(ph, pass, onDone) }, 700)
    }

    @android.annotation.TargetApi(30)
    private fun shotAndPatch(ph: Phase, pass: Int, onDone: () -> Unit) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(res: ScreenshotResult) {
                    var bmp: Bitmap? = null
                    try {
                        val hb = res.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, res.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                    } catch (_: Exception) {}
                    if (bmp == null) { onDone(); return }
                    val b = bmp
                    val pb = panel
                    val pl = IntArray(2)
                    var pr = Rect(0, 0, 0, 0)
                    if (pb != null) {
                        try { pb.getLocationOnScreen(pl); pr = Rect(pl[0] - 6, pl[1] - 6, pl[0] + pb.width + 6, pl[1] + pb.height + 6) } catch (_: Exception) {}
                    }
                    val panelRect = pr
                    Thread {
                        val strokes = try { findGaps(b, ph, panelRect) } catch (_: Throwable) { emptyList<List<PointF>>() }
                        handler.post {
                            if (!running) return@post
                            if (strokes.isEmpty()) { onDone(); return@post }
                            toast("ترقيع الفراغات (جولة ${pass + 1}): ${strokes.size} خط")
                            val ready = splitLong(order(strokes))
                            ensureSize(smallSize) {
                                drawSeq(ready, 0, true, true) { verifyPhase(ph, pass + 1, onDone) }
                            }
                        }
                    }.start()
                }
                override fun onFailure(errorCode: Int) { onDone() }
            })
        } catch (_: Exception) { onDone() }
    }

    // يقارن لقطة الشاشة بخريطة اللون المطلوبة ويُرجع خطوطاً تغطي كل ما لم يُلوَّن
    private fun findGaps(bmp: Bitmap, ph: Phase, panelRect: Rect): List<List<PointF>> {
        val lbl = Shared.lbl ?: return emptyList()
        val iw = Shared.imgW
        val ih = Shared.imgH
        if (lbl.size < iw * ih) return emptyList()
        val bw = bmp.width
        val bh = bmp.height
        val px = IntArray(bw * bh)
        bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
        val saved = prefs().getFloat("brushScreen", 0f)
        val brush = if (saved > 0f) saved else 4f
        val step = Math.max(1, Math.round(brush * 0.7f))
        val e = Math.max(1, Math.round(1.5f / mapSc))
        val x0 = Math.max(0, Math.ceil(mapOx.toDouble()).toInt())
        val y0 = Math.max(0, Math.ceil(mapOy.toDouble()).toInt())
        val x1 = Math.min(bw - 1, Math.floor((mapOx + iw * mapSc).toDouble()).toInt())
        val y1 = Math.min(bh - 1, Math.floor((mapOy + ih * mapSc).toDouble()).toInt())
        if (x1 <= x0 || y1 <= y0) return emptyList()
        val gw = (x1 - x0) / step + 1
        val gh = (y1 - y0) / step + 1
        val unc = BooleanArray(gw * gh)
        var total = 0
        var miss = 0
        val tol = 90
        for (gy in 0 until gh) {
            val sy = y0 + gy * step
            val iy = ((sy - mapOy) / mapSc).toInt()
            if (iy < e || iy >= ih - e) continue
            for (gx in 0 until gw) {
                val sx = x0 + gx * step
                val ix = ((sx - mapOx) / mapSc).toInt()
                if (ix < e || ix >= iw - e) continue
                val i = iy * iw + ix
                if (lbl[i] != ph.cid) continue
                if (lbl[i - e] != ph.cid || lbl[i + e] != ph.cid || lbl[i - e * iw] != ph.cid || lbl[i + e * iw] != ph.cid) continue
                if (panelRect.contains(sx, sy)) continue
                total++
                if (colorDist(px[sy * bw + sx], ph.color) > tol) { unc[gy * gw + gx] = true; miss++ }
            }
        }
        if (total == 0 || miss < Math.max(3, total / 1000)) return emptyList()
        val out = ArrayList<List<PointF>>()
        val half = Math.max(1f, brush / 2f)
        for (gy in 0 until gh) {
            val sy = (y0 + gy * step).toFloat()
            var gx = 0
            while (gx < gw) {
                if (!unc[gy * gw + gx]) { gx++; continue }
                var gx2 = gx
                while (gx2 + 1 < gw && unc[gy * gw + gx2 + 1]) gx2++
                var a = (x0 + gx * step).toFloat()
                var c = (x0 + gx2 * step).toFloat()
                if (c - a < half * 2f) { a -= half; c += half }
                out.add(if (gy % 2 == 0) listOf(PointF(a, sy), PointF(c, sy)) else listOf(PointF(c, sy), PointF(a, sy)))
                gx = gx2 + 1
            }
        }
        return out
    }

    // ---------- وضع Fill ----------
    private fun tapSeq(list: List<PointF?>, i: Int, onDone: () -> Unit) {
        if (!running) return
        if (i >= list.size) { onDone(); return }
        val p = list[i]
        if (p == null) { tapSeq(list, i + 1, onDone); return }
        tapAt(p.x, p.y, 60) { tapSeq(list, i + 1, onDone) }
    }

    // اختيار الأداة: بالتعليم المحفوظ، وإلا يطلب منك اختيارها يدوياً
    private fun selectSel(sel: List<PointF?>?, prompt: String, onDone: () -> Unit) {
        if (!running) return
        if (sel != null) {
            tapSeq(sel, 0) { handler.postDelayed({ if (running) onDone() }, 500) }
        } else {
            waitStep(prompt) { handler.postDelayed({ if (running) onDone() }, 500) }
        }
    }

    private fun selectTool(fill: Boolean, onDone: () -> Unit) = selectSel(
        if (fill) fillSel else brushSel,
        if (fill) "اختر أداة التعبئة (Fill) في Sketchbook بنفسك ثم اضغط متابعة"
        else "اختر الفرشاة/القلم الرفيع في Sketchbook بنفسك ثم اضغط متابعة",
        onDone
    )

    private fun setColorThen(ph: Phase, total: Int, onDone: () -> Unit) {
        if (!running) return
        if (ph.color == curColor) { onDone(); return }
        stepNo++
        if (colorPts != null) {
            applyColor(ph.color) { curColor = ph.color; onDone() }
        } else {
            showColorCard(ph, stepNo, total) {
                curColor = ph.color
                handler.postDelayed({ if (running) onDone() }, 700)
            }
        }
    }

    private fun tapSeeds(seeds: List<PointF>, i: Int, onDone: () -> Unit) {
        if (!running) return
        if (i >= seeds.size) { onDone(); return }
        tapAtD(seeds[i].x, seeds[i].y, 50, 450L) { tapSeeds(seeds, i + 1, onDone) }
    }

    // فحص الإغلاق: قبل ضغط Fill نحاكي التعبئة على لقطة الشاشة. إن تجاوزت المساحة المتوقعة فالمنطقة غير مغلقة
    @android.annotation.TargetApi(30)
    private fun checkClosed(seed: PointF, ring: Int, expected: Float, tries: Int = 0, cb: (Boolean) -> Unit) {
        // أي فشل أو عدم يقين = غير آمن (لا نضغط Fill أبداً دون تحقق)
        fun retry() { if (tries < 3) handler.postDelayed({ checkClosed(seed, ring, expected, tries + 1, cb) }, 700) else cb(false) }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(res: ScreenshotResult) {
                    var ok = false
                    try {
                        val hb = res.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, res.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        if (bmp != null) {
                            val bw = bmp.width
                            val bh = bmp.height
                            val px = IntArray(bw * bh)
                            bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
                            val sx = seed.x.toInt().coerceIn(0, bw - 1)
                            val sy = seed.y.toInt().coerceIn(0, bh - 1)
                            if (colorDist(px[sy * bw + sx], ring) > 40) {
                                val limit = (expected * 1.6f + 300f).toInt()
                                val seen = BooleanArray(bw * bh)
                                val q = IntArray(Math.min(bw * bh, limit + 10))
                                var hd = 0
                                var tl = 0
                                q[tl++] = sy * bw + sx
                                seen[sy * bw + sx] = true
                                var over = false
                                while (hd < tl && !over) {
                                    val i = q[hd++]
                                    val x = i % bw
                                    val y = i / bw
                                    val nb = intArrayOf(if (x > 0) i - 1 else -1, if (x < bw - 1) i + 1 else -1, if (y > 0) i - bw else -1, if (y < bh - 1) i + bw else -1)
                                    for (j in nb) {
                                        if (j < 0 || seen[j] || colorDist(px[j], ring) <= 40) continue
                                        seen[j] = true
                                        if (tl >= q.size) { over = true; break }
                                        q[tl++] = j
                                    }
                                }
                                ok = !(over || tl > limit)
                            }
                        }
                    } catch (_: Exception) {}
                    cb(ok)
                }
                override fun onFailure(errorCode: Int) { retry() }
            })
        } catch (e: Exception) { retry() }
    }

    private fun runFillMode(ps: List<Phase>) {
        val total = ps.size
        val tasks = ArrayList<(() -> Unit) -> Unit>()
        // لكل لون: لون ← طبقة جديدة ← حدود المنطقة ← أداة Fill ← ضغطات التعبئة ← العودة للفرشاة
        for (ph in ps) {
            val seeds = ph.fills
            if (ph.strokes.isEmpty() && seeds.isNullOrEmpty()) continue
            tasks.add { next ->
                showBanner("${ph.label}\nاللون ${String.format("#%06X", 0xFFFFFF and ph.color)}")
                setColorThen(ph, total) {
                    newLayer {
                        drawNext(ph.strokes, 0, ph.fast) {
                            if (seeds.isNullOrEmpty()) {
                                next()
                            } else {
                                val areas = ph.fillAreas
                                val fbs = ph.fillFallback
                                val bad = ArrayList<Int>()
                                fun seedLoop(i: Int, done: () -> Unit) {
                                    if (!running) return
                                    if (i >= seeds.size) { done(); return }
                                    fun tapIt() { tapAtD(seeds[i].x, seeds[i].y, 50, 450L) { seedLoop(i + 1, done) } }
                                    if (areas == null || i >= areas.size) { tapIt(); return }
                                    handler.postDelayed({
                                        checkClosed(seeds[i], ph.color, areas[i]) { ok ->
                                            if (ok) tapIt() else { bad.add(i); seedLoop(i + 1, done) }
                                        }
                                    }, 450)
                                }
                                selectTool(true) {
                                    seedLoop(0) {
                                        selectTool(false) {
                                            if (bad.isEmpty() || fbs == null) next()
                                            else {
                                                toast("${bad.size} منطقة غير مغلقة: تُلوَّن بالفرشاة بدل Fill")
                                                val st = ArrayList<List<PointF>>()
                                                for (b in bad) if (b < fbs.size) st.addAll(fbs[b])
                                                drawNext(st, 0, ph.fast) { next() }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        fun go(i: Int) {
            if (!running) return
            if (i >= tasks.size) {
                running = false
                removeOverlay(banner); banner = null
                notifyDone()
                return
            }
            tasks[i].invoke { go(i + 1) }
        }
        go(0)
    }

    // تقسيم المسارات الطويلة جداً حتى لا تتجاوز حد مدة الإيماءة
    private fun splitLong(list: List<List<PointF>>): List<List<PointF>> {
        val out = ArrayList<List<PointF>>()
        for (st in list) {
            var cur = ArrayList<PointF>()
            var len = 0f
            for (k in st.indices) {
                if (cur.isNotEmpty()) {
                    val dx = st[k].x - cur.last().x
                    val dy = st[k].y - cur.last().y
                    len += Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                }
                cur.add(st[k])
                if (len > 18000f && k < st.size - 1) {
                    out.add(cur)
                    cur = ArrayList()
                    cur.add(st[k])
                    len = 0f
                }
            }
            if (cur.size >= 2) out.add(cur)
        }
        return out
    }

    private fun order(list: List<List<PointF>>): List<List<PointF>> {
        if (list.isEmpty() || list.size > 1500) return list
        val rem = list.toMutableList()
        val out = ArrayList<List<PointF>>()
        var cx = 0f
        var cy = 0f
        while (rem.isNotEmpty()) {
            var best = -1
            var bd = Float.MAX_VALUE
            var rev = false
            for (i in rem.indices) {
                val a = rem[i].first()
                val b = rem[i].last()
                val da = (a.x - cx) * (a.x - cx) + (a.y - cy) * (a.y - cy)
                val db = (b.x - cx) * (b.x - cx) + (b.y - cy) * (b.y - cy)
                if (da < bd) { bd = da; best = i; rev = false }
                if (db < bd) { bd = db; best = i; rev = true }
            }
            val st = rem.removeAt(best)
            val o = if (rev) st.reversed() else st
            out.add(o)
            cx = o.last().x
            cy = o.last().y
        }
        return out
    }

    private var cancelStreak = 0

    // يرسل إيماءة بأمان: لا يُسقط التطبيق إن رفض النظام المسار، ويعيد المحاولة عند الإلغاء،
    // ويتجاوز الخط بدل إيقاف الرسم كله، ومؤقّت حماية يمنع التعليق إن لم يصل ردّ النظام.
    private fun sendGesture(build: () -> GestureDescription?, expectMs: Long, attempt: Int, onOk: () -> Unit, onSkip: () -> Unit) {
        if (!running) return
        val g = try { build() } catch (_: Throwable) { null }
        if (g == null) { onSkip(); return }
        var fin = false
        lateinit var wd: Runnable
        val fail = {
            if (running) {
                if (attempt < 2) {
                    handler.postDelayed({ sendGesture(build, expectMs, attempt + 1, onOk, onSkip) }, 250L * (attempt + 1))
                } else {
                    cancelStreak++
                    if (cancelStreak >= 4) {
                        running = false
                        toast("توقف الرسم لأن النظام يلغي الإيماءات: تأكد أنك لا تلمس الشاشة وأن الخدمة مفعّلة")
                    } else onSkip()
                }
            }
        }
        wd = Runnable { if (!fin) { fin = true; fail() } }
        val ok = try {
            dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) {
                    if (fin) return
                    fin = true
                    handler.removeCallbacks(wd)
                    cancelStreak = 0
                    onOk()
                }
                override fun onCancelled(d: GestureDescription?) {
                    if (fin) return
                    fin = true
                    handler.removeCallbacks(wd)
                    fail()
                }
            }, null)
        } catch (_: Throwable) { false }
        if (ok) handler.postDelayed(wd, expectMs + 4000L)
        else { fin = true; fail() }
    }

    private fun cleanPts(src: List<PointF>): List<PointF> {
        val o = ArrayList<PointF>(src.size)
        for (p in src) {
            if (p.x.isNaN() || p.y.isNaN()) continue
            val q = PointF(p.x.coerceAtLeast(0f), p.y.coerceAtLeast(0f))
            if (o.isNotEmpty() && o.last().x == q.x && o.last().y == q.y) continue
            o.add(q)
        }
        return o
    }

    private fun lengthOf(pts: List<PointF>): Float {
        var len = 0f
        for (k in 1 until pts.size) {
            val dx = pts[k].x - pts[k - 1].x
            val dy = pts[k].y - pts[k - 1].y
            len += Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
        return len
    }

    private fun pathOf(pts: List<PointF>): Path {
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (k in 1 until pts.size - 1) {
            path.quadTo(pts[k].x, pts[k].y, (pts[k].x + pts[k + 1].x) / 2f, (pts[k].y + pts[k + 1].y) / 2f)
        }
        path.lineTo(pts.last().x, pts.last().y)
        return path
    }

    // مدّة الخط بالمللي ثانية. حتى x2 السلوك القديم كما هو. فوق x2 نرفع السرعة تدريجياً (لا خطياً)
    // حتى يبقى الخط مأخوذ العيّنات كفاية فلا تتقصّر أطرافه، والتسريع الحقيقي يأتي من تجميع الخطوط.
    private fun strokeMs(len: Float, straight: Boolean, fast: Boolean, mult: Float): Long {
        val base = if (fast) 0.8f + Random.nextFloat() * 0.5f else 0.5f + Random.nextFloat() * 0.5f
        val sp: Float
        val minMs: Long
        if (mult <= 2f) {
            sp = if (straight) base * mult else base * (1f + (mult - 1f) * 0.25f)
            minMs = if (mult > 1f) 35L else 120L
        } else {
            sp = if (straight) base * (1f + (mult - 1f) * 0.5f) else base * (1f + (mult - 1f) * 0.25f)
            minMs = 60L
        }
        return (len / sp).toLong().coerceIn(minMs, 55000L)
    }

    // precise: للترقيع، تُرسم الخطوط بسرعة x2 كحدّ أقصى وبلا تجميع ليكون الترقيع مضبوطاً
    private fun drawNext(strokes: List<List<PointF>>, i: Int, fast: Boolean, onDone: () -> Unit) =
        drawSeq(strokes, i, fast, false, onDone)

    private fun drawSeq(strokes: List<List<PointF>>, i: Int, fast: Boolean, precise: Boolean, onDone: () -> Unit) {
        if (!running) return
        if (i >= strokes.size) { onDone(); return }
        val rawMult = Shared.speed.coerceIn(1f, 10f)
        val mult = if (precise) Math.min(rawMult, 2f) else rawMult
        // سرعة الخط نفسه: x2 تساوي x1 تماماً (دقة كاملة)، ويأتي تسريعها من تقصير الفواصل بين الخطوط فقط
        val pace = if (mult <= 2f) 1f else mult

        val first = cleanPts(strokes[i])
        if (first.size < 2) { drawSeq(strokes, i + 1, fast, precise, onDone); return }

        // ---- تجميع الخطوط المستقيمة (x3 فأكثر): إيماءة واحدة بعدة خطوط متتالية بلا تأخير بين الإيماءات ----
        if (mult >= 3f && !precise && first.size == 2) {
            val maxStrokes = Math.min(8, GestureDescription.getMaxStrokeCount())
            val liftGap = 18L
            val batch = ArrayList<Pair<Path, Long>>()
            var t = 0L
            var j = i
            while (j < strokes.size && batch.size < maxStrokes) {
                val pts = if (j == i) first else cleanPts(strokes[j])
                if (pts.size != 2) break
                val ms = strokeMs(lengthOf(pts), true, fast, pace)
                if (batch.isNotEmpty() && t + ms > 3500L) break
                batch.add(Pair(pathOf(pts), ms))
                t += ms + liftGap
                j++
            }
            if (batch.size >= 2) {
                val total = t
                val next = j
                sendGesture({
                    val b = GestureDescription.Builder()
                    var st = 0L
                    for ((path, ms) in batch) {
                        b.addStroke(GestureDescription.StrokeDescription(path, st, ms))
                        st += ms + liftGap
                    }
                    b.build()
                }, total, 0, {
                    handler.postDelayed({ drawSeq(strokes, next, fast, precise, onDone) }, 22L)
                }, {
                    drawSeq(strokes, next, fast, precise, onDone)
                })
                return
            }
        }

        val len = lengthOf(first)
        val straight = first.size == 2
        val duration = strokeMs(len, straight, fast, pace)
        val path = pathOf(first)
        sendGesture({
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                .build()
        }, duration, 0, {
            val m2 = mult
            val pause = if (m2 <= 1f) {
                if (fast) {
                    if (Random.nextInt(40) == 0) Random.nextLong(800, 2000) else Random.nextLong(30, 150)
                } else {
                    if (Random.nextInt(12) == 0) Random.nextLong(1500, 3500) else Random.nextLong(100, 500)
                }
            } else if (m2 > 2f) {
                Math.max(22L, (Random.nextLong(30, 150) / m2).toLong())
            } else {
                Math.max(15L, (Random.nextLong(30, 150) / m2).toLong())
            }
            handler.postDelayed({ drawSeq(strokes, i + 1, fast, precise, onDone) }, pause)
        }, {
            drawSeq(strokes, i + 1, fast, precise, onDone)
        })
    }
}
